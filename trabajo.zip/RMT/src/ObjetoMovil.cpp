#include"ObjetoMovil.h"
void ObjetoMovil::mueve(float t) {
	posicion = posicion + velocidad * t + aceleracion * t * t * 0.5f;
	velocidad = velocidad + aceleracion * t;
}
void ObjetoMovil::SetPos(float ix, float iy)
{
	posicion.x = ix;
	posicion.y = iy;
}

void ObjetoMovil::SetVel(float ix, float iy)
{
	velocidad.x = ix;
	velocidad.y = iy;
}

Vector2D ObjetoMovil::GetPos() {
	return posicion;
}