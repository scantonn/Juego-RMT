#pragma once
#include "Vector2D.h"
#include"ObjetoMovil.h"

class Bonus : public ObjetoMovil
{
	float lado;
public:
	Bonus();
	virtual ~Bonus();
	void Dibuja();
};


