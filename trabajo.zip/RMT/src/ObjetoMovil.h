#pragma once
#include"Vector2D.h"
class ObjetoMovil {
protected:
	Vector2D posicion;
	Vector2D velocidad;
	Vector2D aceleracion;
public:
	virtual void mueve(float);
	void SetPos(float ix, float iy);
	void SetVel(float ix, float iy);
	Vector2D GetPos();
};